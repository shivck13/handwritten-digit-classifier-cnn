@echo off
echo Opening the GUI app
python gui-minimal.py